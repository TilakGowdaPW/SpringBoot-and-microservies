package ai.ineuron.DTO;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.LockModeType;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.Data;

@Data
@Table(name = "studentresult")
@Entity
@NamedQuery(name = "query", query = "select hi from StudentEntity hi where hi.rollNo=:roll")
public class StudentEntity {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(name = "name")
	private String name;
	@Column(name = "rollNo")
	private int rollNo;
	@Column(name = "result")
	private char result;
}
