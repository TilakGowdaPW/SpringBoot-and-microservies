package ai.ineuron.DTO;

import lombok.Data;

@Data
public class StudentDto {

	private int id;
	private String name;
	private int rollNo;
	private char result;
}
