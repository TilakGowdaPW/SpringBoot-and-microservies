package ai.ineuron.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

@Configuration
@ComponentScan("ai.ineuron")
public class ResultConfiguration {
	public ResultConfiguration() {
		System.out.println("Running config");
	}

	@Bean
	public LocalContainerEntityManagerFactoryBean bean() {
		System.out.println("ResultConfiguration.bean()");
		LocalContainerEntityManagerFactoryBean bean = new LocalContainerEntityManagerFactoryBean();
		System.out.println(bean);
		return bean;
	}
}
