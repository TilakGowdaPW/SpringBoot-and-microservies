package ai.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ai.ineuron.DTO.StudentDto;
import ai.ineuron.DTO.StudentEntity;
import ai.ineuron.repository.ResultRepository;

@Service
public class ResultServiceImpl implements ResultService {

	@Autowired
	private ResultRepository repository;

	public ResultServiceImpl() {
		System.out.println("Running Service");
	}

	@Override
	public StudentDto getResult(int no) {
		System.out.println("Running getResult in service");

		StudentEntity dto = repository.findByNo(no);
		if (dto != null) {
			StudentDto dto2 = new StudentDto();
			dto2.setId(dto.getId());
			dto2.setName(dto.getName());
			dto2.setResult(dto.getResult());
			dto2.setRollNo(dto.getRollNo());

			return dto2;
		} else {
			return null;
		}
	}

	@Override
	public void addResult(StudentDto dto) {
		System.out.println("Running addResult iin service");
		StudentEntity entity = new StudentEntity();
		entity.setName(dto.getName());
		entity.setResult(dto.getResult());
		entity.setRollNo(dto.getRollNo());
		repository.addKaro(entity);
	}

	@Override
	public boolean deleteit(int no) {
		boolean re = repository.deletekaro(no);
		if (re = true) {
			return true;
		} else {
			return false;
		}
	}
}
