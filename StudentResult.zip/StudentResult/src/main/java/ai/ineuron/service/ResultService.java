package ai.ineuron.service;

import ai.ineuron.DTO.StudentDto;

public interface ResultService {
	default StudentDto getResult(int no) {
		return null;
	};

	default void addResult(StudentDto dto) {

	}
	
	default boolean deleteit(int no) {
		return false;
	}
}
