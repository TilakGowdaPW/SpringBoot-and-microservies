package ai.ineuron.repository;



import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

import ai.ineuron.DTO.StudentEntity;

@Repository
public class ResultRepositoryImpl implements ResultRepository {

	@Autowired
	private EntityManagerFactory factory;

	@Override
	public StudentEntity findByNo(int no) {
		System.out.println("ResultRepositoryImpl.findByNo()");
		System.out.println(factory.getClass().getName());
		EntityManager entitymanager = factory.createEntityManager();
		Query query = entitymanager.createNamedQuery("query");
		query.setParameter("roll", no);
		StudentEntity ref = (StudentEntity) query.getSingleResult();
		return ref;

	}

	@Override
	public void addKaro(StudentEntity dto) {
		System.out.println("Running addkaro");

		EntityManager fact = factory.createEntityManager();
		EntityTransaction transaction = fact.getTransaction();
		transaction.begin();
		fact.persist(dto);
		transaction.commit();
		fact.close();

	}

	@Override
	public boolean deletekaro(int no) {
		EntityManager fact = factory.createEntityManager();
		EntityTransaction transaction = fact.getTransaction();
		transaction.begin();
		fact.remove(fact.find(StudentEntity.class, no));
		transaction.commit();
		fact.close();
		return true;
	}

}
