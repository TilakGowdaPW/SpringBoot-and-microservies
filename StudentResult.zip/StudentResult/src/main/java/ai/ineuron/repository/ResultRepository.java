package ai.ineuron.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ai.ineuron.DTO.StudentDto;
import ai.ineuron.DTO.StudentEntity;
import ai.ineuron.Ex.NoResultException;

public interface ResultRepository {

	default StudentEntity findByNo(int no)  {
		return null;
	};

	default void addKaro(StudentEntity dto) {

	}

	default boolean deletekaro(int no) {
		return false;
	}

}
