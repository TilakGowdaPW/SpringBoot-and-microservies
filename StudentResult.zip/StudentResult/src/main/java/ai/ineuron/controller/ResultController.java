package ai.ineuron.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ai.ineuron.DTO.StudentDto;
import ai.ineuron.service.ResultService;
import jakarta.validation.Valid;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;

@Controller
@RequestMapping("/")
public class ResultController {

	@Autowired
	private ResultService resultService;

	public ResultController() {
		System.out.println("Running Controller");
	}

	@PostMapping("/result")
	public String getResult(@RequestParam int rollno, Model model) {
		System.out.println("Running getResult");
		System.out.println(rollno);
		 
		StudentDto dto = resultService.getResult(rollno);
		if (dto != null) {
			model.addAttribute("dto", dto);
		} else {
			model.addAttribute("no", "Data not found");
		}

		return "result.jsp";
	}

	@PostMapping("/addResult")
	public String addResult(StudentDto dto) {
		System.out.println("Running addResult");
		resultService.addResult(dto);
		return "success.jsp";
	}

	@GetMapping("/delete")
	public String del(int id, Model model) {
		System.out.println("Running delete");
		System.out.println(id);
		boolean re = resultService.deleteit(id);
		if (re = true) {
			model.addAttribute("re", "Deleted");
		} else {
			model.addAttribute("ref", "not deleted");
		}
		return "result.jsp";
	}
}
